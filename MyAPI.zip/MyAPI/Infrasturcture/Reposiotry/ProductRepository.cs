﻿using ApplicationLayer.Interfaces;
using DBHelper;
using Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrasturcture.Reposiotry
{
    public class ProductRepository : IProductRepository
    {
        private readonly SQLHelper _sqlHelper;
        public ProductRepository(string connectionString)
        {
            _sqlHelper = new SQLHelper(connectionString);
        }

        public async Task AddAsync(Product product)
        {
            const string query = "UpdateAndInsertProduct";
            var parameters = new[]
            {
    new SqlParameter("@Operation", "Add"),
    new SqlParameter("@Name", product.Name),
    new SqlParameter("@Category", product.Category),
    new SqlParameter("@Price", product.Price)
};
            await _sqlHelper.ExecuteNonQueryAsync(query, CommandType.StoredProcedure, parameters);


        }

        public async Task UpdateAsync(Product product)
        {
            const string query = "UpdateAndInsertProduct";
            var parameters = new[]
            {
    new SqlParameter("@Operation", "Update"),
    new SqlParameter("@ProductId", product.Id),
    new SqlParameter("@Name", product.Name),
    new SqlParameter("@Category", product.Category),
    new SqlParameter("@Price", product.Price)
};
            await _sqlHelper.ExecuteNonQueryAsync(query, CommandType.StoredProcedure, parameters);


        }

        public async Task DeleteAsync(int id)
        {
            const string query = "UpdateAndInsertProduct";
            var parameters = new[]
            {
    new SqlParameter("@Operation", "Delete"),
    new SqlParameter("@ProductId", id)
};
            await _sqlHelper.ExecuteNonQueryAsync(query, CommandType.StoredProcedure, parameters);

        }

        public async Task<IEnumerable<Product>> GetAllAsync()
        {
            const string query = "UpdateAndInsertProduct";
            var parameters = new[]
            {
    new SqlParameter("@Operation", "GetAll")
};
            var dataTable = await _sqlHelper.ExecuteQueryAsync(query, CommandType.StoredProcedure, parameters);

            return dataTable.AsEnumerable().Select(row => new Product
            {
                Id = row.Field<int>("Id"),
                Name = row.Field<string>("Name"),
                Category = row.Field<string>("Category"),
                Price = row.Field<decimal>("Price")
            }).ToList();

        }

        public async Task<Product?> GetByIdAsync(int id)
        {
            const string query = "UpdateAndInsertProduct";
            var parameters = new[]
            {
    new SqlParameter("@Operation", "GetById"),
    new SqlParameter("@ProductId", id)
};
            var dataTable = await _sqlHelper.ExecuteQueryAsync(query, CommandType.StoredProcedure, parameters);

            if (dataTable.Rows.Count == 0) return null;

            var row = dataTable.Rows[0];
            return new Product
            {
                Id = row.Field<int>("Id"),
                Name = row.Field<string>("Name"),
                Category = row.Field<string>("Category"),
                Price = row.Field<decimal>("Price")
            };

        }

    }
}
